package com.globalkinetic.restjersey;

import java.util.List;
import java.util.UUID;

import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.Response;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

@Path("/api")
public class UserService {

	UserDao userDao = new UserDao();

	private static final String SUCCESS_RESULT = "success";
	private static final String FAILURE_RESULT = "failure";

	@GET
	@Path("/users")
	@Produces("application/json")
	public Response getAllUser() throws JSONException {

		List<User> userlist = userDao.getAllUsers();
		if (userlist == null) {
			return Response.status(401).entity(FAILURE_RESULT).build();
		}

		JSONArray jArray = new JSONArray();
		for (User user : userlist) {

			int id_json = user.getId();
			String username_json = user.getUsername();
			String password_json = user.getPassword();
			String phone_json = user.getPhone();
			JSONObject jobj = new JSONObject();
			jobj.put("id", id_json);
			jobj.put("username", username_json);
			jobj.put("password", password_json);
			jobj.put("phone", phone_json);
			jArray.put(jobj);
		}

		JSONObject users = new JSONObject();
		users.put("users", jArray);

		String result = users.toString();
		return Response.status(200).entity(result).build();
	}

	@GET
	@Path("/user/{id}")
	@Produces("application/json")
	public Response getUser(@PathParam("id") int id) throws JSONException {

		User user = userDao.getUser(id);

		if (user == null) {
			return Response.status(401).entity(FAILURE_RESULT).build();
		}

		int id_json = user.getId();
		String username_json = user.getUsername();
		String password_json = user.getPassword();
		String phone_json = user.getPhone();
		JSONObject jobj = new JSONObject();
		jobj.put("id", id_json);
		jobj.put("username", username_json);
		jobj.put("password", password_json);
		jobj.put("phone", phone_json);
		String result = jobj.toString();
		return Response.status(200).entity(result).build();

	}
	
	@POST
	@Path("/user/add")
	@Produces("application/json")
	public Response createUser(String body) throws JSONException {

		JSONObject obj=new JSONObject(body);
		User user = new User();
		user.setUsername(obj.getString("username"));
		user.setPassword(obj.getString("password"));
		user.setPhone(obj.getString("phone"));
		int adduser = userDao.addUser(user);

		if (adduser == 0) {
			return Response.status(401).entity(FAILURE_RESULT).build();
		}

		return getAllUser();

	}
	


	@POST
	@Path("/user/add/{username}/{password}/{phone}")
	@Produces("application/json")
	public Response addUserWithParameter(@PathParam("username") String username,
			@PathParam("password") String password,
			@PathParam("phone") String phone) throws JSONException {

		User user = new User();
		user.setUsername(username);
		user.setPassword(password);
		user.setPhone(phone);
		int adduser = userDao.addUser(user);

		if (adduser == 0) {
			return Response.status(401).entity(FAILURE_RESULT).build();
		}

		return Response.status(200).entity(SUCCESS_RESULT).build();

	}
	
	@PUT
	@Path("/user/update/{id}")
	@Produces("application/json")
	public Response updateUser(@PathParam("id") int id,String body) throws JSONException {

		JSONObject obj=new JSONObject(body);
		User user = new User();
		user.setId(id);
		user.setUsername(obj.getString("username"));
		user.setPassword(obj.getString("password"));
		user.setPhone(obj.getString("phone"));
		int updateuser = userDao.updateUser(user);

		if (updateuser == 0) {
			return Response.status(401).entity(FAILURE_RESULT).build();
		}

		return getAllUser();

	}
	
	@DELETE
	@Path("/user/delete/{id}")
	@Produces("application/json")
	public Response deleteUser(@PathParam("id") int id) throws JSONException {

	
		int deleteuser = userDao.deleteUser(id);

		if (deleteuser == 0) {
			return Response.status(401).entity(FAILURE_RESULT).build();
		}

		return getAllUser();

	}
	
	@POST
	@Path("/user/login")
	@Produces("application/json")
	public Response userLogin(String body) throws JSONException {

		JSONObject obj=new JSONObject(body);
		
		User user = userDao.userLogin(obj.getString("username"), obj.getString("password"));
		if(user==null) {
			return Response.status(401).entity(FAILURE_RESULT).build();
		}
		
		
		  UUID uuid = UUID.randomUUID();
	        String token = uuid.toString().replace("-", "");
		JSONObject jobj = new JSONObject();
		jobj.put("id", user.getId());
		jobj.put("token", token);
	

	String result = jobj.toString();
	return Response.status(200).entity(result).build();
	

	}
	@POST
	@Path("/user/logout/{id}")
	@Produces("application/json")
	public Response userLogout(@PathParam("id") int id) throws JSONException {

		
		
		User user = userDao.getUser(id);
		if(user==null) {
			return Response.status(401).entity(FAILURE_RESULT).build();
		}	
		
		  UUID uuid = UUID.randomUUID();
	        String token = uuid.toString().replace("-", "");
		JSONObject jobj = new JSONObject();
			jobj.put("token", token);
	

	String result = jobj.toString();
	return Response.status(200).entity(result).build();
	

	}
	

}
