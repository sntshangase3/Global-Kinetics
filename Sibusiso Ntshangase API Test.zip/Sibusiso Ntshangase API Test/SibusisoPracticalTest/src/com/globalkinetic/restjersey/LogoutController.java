package com.globalkinetic.restjersey;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONObject;
 
/**
 * Servlet implementation class LogoutSession
 */
public class LogoutController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	String token;
	protected void doPost(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		final String POST_PARAMS = "1";
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("Bye!!!Your session was destroyed successfully!!");
		HttpSession session = request.getSession(false);
		
		try {
			
			URL obj = new URL("http://localhost:8080/global/global/api/user/logout/1");
			HttpURLConnection postConnection = (HttpURLConnection) obj.openConnection();
			postConnection.setRequestMethod("POST");
			postConnection.setRequestProperty("Content-Type", "application/json");
			postConnection.setDoOutput(true);
			/*OutputStream os = postConnection.getOutputStream();
			os.write(POST_PARAMS.getBytes());
			os.flush();
			os.close();*/
			int responseCode = postConnection.getResponseCode();

			if (responseCode == HttpURLConnection.HTTP_OK) { // success
				BufferedReader in = new BufferedReader(new InputStreamReader(postConnection.getInputStream()));
				String inputLine;
				StringBuffer login = new StringBuffer();

				while ((inputLine = in.readLine()) != null) {
					login.append(inputLine);
				}
				in.close();

				JSONObject jobj = new JSONObject(login.toString());
			
				token = jobj.get("token").toString();

			}
			} catch (Exception e) {
			
		}
		session.removeAttribute("user");
		session.setAttribute("token", token);
		session.getMaxInactiveInterval();
	}
}
