package com.globalkinetic.restjersey;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;


public class ConnectionClass {
   
    public Connection connectionclass(String user, String password, String database, String server)
    {
     
        Connection connection = null;
        String ConnectionURL = null;
        try
        {
            Class.forName("net.sourceforge.jtds.jdbc.Driver");
            ConnectionURL = "jdbc:jtds:sqlserver://" + server +":1433/"+ database + ";user=" + user+ ";password=" + password + ";";
            DriverManager.setLoginTimeout(600000);
            Properties properties = new Properties();
            properties.put("connectTimeout", "600000");
            connection = DriverManager.getConnection(ConnectionURL,properties);


        }
        catch (SQLException se)
        {
          //  Log.e("error here 1 : ", se.getMessage());
        }
        catch (ClassNotFoundException e)
        {
            //Log.e("error here 2 : ", e.getMessage());
        }
        catch (Exception e)
        {
           // Log.e("error here 3 : ", e.getMessage());
        }
        return connection;
    }
}
