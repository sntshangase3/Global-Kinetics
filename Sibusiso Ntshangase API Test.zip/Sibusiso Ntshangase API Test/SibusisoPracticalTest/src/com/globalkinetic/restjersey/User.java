package com.globalkinetic.restjersey;

import java.io.Serializable;




public class User implements Serializable {
	
	private static final long serialVersionUID = 1L;
    private int id;
    private String username;
    private String phone;
    private String password;
    
        
	public User() {
	
	}
	public User(int id, String username, String password,String phone) {
		this.id = id;
		this.username = username;
		this.phone = phone;
		this.password = password;
	}
	public int getId() {
		return id;
	}

	
	public void setId(int id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}
	public String getPhone() {
		return phone;
	}
	
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	   @Override
	   public boolean equals(Object object){ // Check if username,password and phone are the same
	      if(object == null){
	         return false;
	      }else if(!(object instanceof User)){
	         return false;
	      }else {
	         User user = (User)object;
	         if(username.equals(user.getUsername())
	            && password.equals(user.getPassword())
	            && phone.equals(user.getPhone())
	         ){
	            return true;
	         }			
	      }
	      return false;
	   }
    
    
}
