package com.globalkinetic.restjersey;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 * Servlet implementation class Session
 */
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	String id, token;

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String output, userList = "";
		String un = request.getParameter("uname");
		String pwd = request.getParameter("pass");
		final String POST_PARAMS = "{\n" + "    \"username\": \"" + un + "\",\n" + "    \"password\": \"" + pwd + "\"\n"
				+ "}";

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();

		try {

			URL url = new URL("http://localhost:8080/global/global/api/users");
			HttpURLConnection conn = (HttpURLConnection) url.openConnection();
			conn.setRequestMethod("GET");
			conn.setRequestProperty("Accept", "application/json");

			if (conn.getResponseCode() != 200) {
				throw new RuntimeException("Failed : HTTP error code : " + conn.getResponseCode());
			}

			BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));

			while ((output = br.readLine()) != null) {
				System.out.println(output);
				JSONObject jobj = new JSONObject(output);
				JSONArray jsonarr_1 = jobj.getJSONArray("users");
				System.out.println(jobj.length());
				for (int j = 0; j < jsonarr_1.length(); j++) {

					JSONObject jsonobj_1 = (JSONObject) jsonarr_1.get(j);

					userList = userList + "Username:\t" + jsonobj_1.get("username").toString() + "<br>" + "Password:\t"
							+ jsonobj_1.get("password").toString() + "<br>" + "Phone:\t"
							+ jsonobj_1.get("phone").toString() + "<br>==========<br>";

				}
			}

			conn.disconnect();

			URL obj = new URL("http://localhost:8080/global/global/api/user/login");
			HttpURLConnection postConnection = (HttpURLConnection) obj.openConnection();
			postConnection.setRequestMethod("POST");
			postConnection.setRequestProperty("Content-Type", "application/json");
			postConnection.setDoOutput(true);
			OutputStream os = postConnection.getOutputStream();
			os.write(POST_PARAMS.getBytes());
			os.flush();
			os.close();
			int responseCode = postConnection.getResponseCode();

			if (responseCode == HttpURLConnection.HTTP_OK) { // success
				BufferedReader in = new BufferedReader(new InputStreamReader(postConnection.getInputStream()));
				String inputLine;
				StringBuffer login = new StringBuffer();

				while ((inputLine = in.readLine()) != null) {
					login.append(inputLine);
				}
				in.close();

			
					
				JSONObject jobj = new JSONObject(login.toString());
				
		id = jobj.get("id").toString();
				token = jobj.get("token").toString();
				
				if (!id.equals("") && !token.equals("")) {
					out.print("Welcome, " + un);
					HttpSession session = request.getSession(true); // reuse existing
																	// session if exist
																	// or create one
					session.setAttribute("user", un);
					session.setAttribute("token", token);
					session.setAttribute("userList", userList);
					session.setMaxInactiveInterval(180); // 3 minutes in seconds
					response.sendRedirect("home.jsp");
				} // TODO Auto-generated method stub


			}else {
				RequestDispatcher rd = request.getRequestDispatcher("login.jsp");
				out.println("<font color=red>Either user name or password is wrong.</font>");
				rd.include(request, response);
			}

		}  catch (Exception e) {

			RequestDispatcher rd = request.getRequestDispatcher("login.jsp");
			out.println("<font color=red>Either user name or password is wrong.</font>");
			rd.include(request, response);

		}

		
	}
}