package com.globalkinetic.restjersey;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class UserDao {
	List<User> userList = new ArrayList<User>();
	String ip = "winsqls01.cpt.wa.co.za";
	String db = "SqaloITSolutionsTest";
	String un = "sqaloits";
	String pass = "422q5mfQzU";

	public List<User> getAllUsers() {

		try {

			ConnectionClass cn = new ConnectionClass();
			Connection con = cn.connectionclass(un, pass, db, ip);

			if (con == null) {
				System.out.println("Check your network connection!!");
			} else {
				String query = "select * from [GlobalUser]  order by [id] asc";
				PreparedStatement ps = con.prepareStatement(query);
				ResultSet rs = ps.executeQuery();
				while (rs.next()) {
					User user = new User(Integer.valueOf(rs.getString("id").toString()),
							rs.getString("username").toString(), rs.getString("password").toString(),
							rs.getString("phone").toString());
					userList.add(user);
				}

			}
			con.close();

		} catch (Exception e) {
			System.out.println("Network connection Error:" + e.getMessage());
		}
		return userList;
	}

	public User getUser(int id) {
		List<User> users = getAllUsers();

		for (User user : users) {
			if (user.getId() == id) {
				return user;
			}
		}
		return null;
	}

	public User userLogin(String username, String password) {
		List<User> users = getAllUsers();

		for (User user : users) {
			if (user.getUsername().equals(username) && user.getPassword().equals(password)) {
				return user;
			}
		}
		return null;
	}

	public int addUser(User user_new) {
		List<User> userList = getAllUsers();
		boolean userExists = false;
		for (User user : userList) {
			if (user.equals(user_new)) {
				userExists = true;
				break;
			}
		}
		if (!userExists) {
			userList.add(user_new);
			saveUser(user_new);
			return 1;
		}
		return 0;
	}

	private void saveUser(User user) {
		try {

			ConnectionClass cn = new ConnectionClass();
			Connection con = cn.connectionclass(un, pass, db, ip);

			if (con == null) {
				System.out.println("Check your network connection!!");
			} else {
				String query = "insert into [GlobalUser]([username],[password],[phone]) " + "values ('"
						+ user.getUsername() + "','" + user.getPassword() + "','" + user.getPhone() + "')";
				PreparedStatement preparedStatement = con.prepareStatement(query);
				preparedStatement.executeUpdate();
			}

			con.close();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public int updateUser(User user_new) {
		

		try {

			ConnectionClass cn = new ConnectionClass();
			Connection con = cn.connectionclass(un, pass, db, ip);

			if (con == null) {
				System.out.println("Check your network connection!!");
			} else {
				
						String query = "update [GlobalUser] set [username]='" + user_new.getUsername() + "',[password]='"
								+ user_new.getPassword() + "'," + "[phone]='" + user_new.getPhone() + "' where [id]="
								+ user_new.getId();
						PreparedStatement preparedStatement = con.prepareStatement(query);
						preparedStatement.executeUpdate();
				
			}

			con.close();
			return 1;

		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}
	public int deleteUser(int id) {
	

		try {

			ConnectionClass cn = new ConnectionClass();
			Connection con = cn.connectionclass(un, pass, db, ip);

			if (con == null) {
				System.out.println("Check your network connection!!");
			} else {
				
						String query = "delete from [GlobalUser]  where [id]="+id;
						PreparedStatement preparedStatement = con.prepareStatement(query);
						preparedStatement.executeUpdate();
				
			}

			con.close();
			return 1;

		} catch (Exception e) {
			e.printStackTrace();
		}
		return 0;
	}

}
